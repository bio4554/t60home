rm build.zip
zip -r build.zip **
rm -r build